ActiveRecord::Base.send :include, ActiveRecord::Acts::Tree
